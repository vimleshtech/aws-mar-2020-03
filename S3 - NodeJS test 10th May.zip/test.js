var aws = require('aws-sdk')

var id="AKIASJN7VJB3KZ7QOIOS"
var key="F/uM7ypehroiP7jnOn3zqdJQw/9QSaFyTThw+A5U"

var s3 = new aws.S3({
    accessKeyId:id,
    secretAccessKey:key, 
})


create_bucket =(name)=>{

    
        var params = {
            Bucket: name,
            CreateBucketConfiguration: {                
                LocationConstraint: "eu-west-1"
            }
        };

        s3.createBucket(params, function(err, data) {
            if (err) console.log(err, err.stack);

            else console.log('Bucket Created Successfully', data.Location);
        });

        

}




upload_file =()=>{
    
    console.log('hi, i am about create buceket')
    console.log('hi, i am about create buceket')
    console.log('hi, i am about create buceket')
    console.log('hi, i am about create buceket')
    console.log('hi, i am about create buceket')
    console.log('hi, i am about create buceket')
    console.log('hi, i am about create buceket')
    console.log('hi, i am about create buceket')
    console.log('hi, i am about create buceket')
    console.log('hi, i am about create buceket')
    console.log('hi, i am about create buceket')
    console.log('hi, i am about create buceket')
    console.log('hi, i am about create buceket')
    


}










//call   to function 
create_bucket("my-learning-bucket-11156600883333")
//upload_file()
//upload_file()


